STUDENT REGISTRATION PORTAL - PRACTICAL 2
==========================================

Features:
- Flask application
- Flask-WTF registration form
- Name field (required)
- Email field (required and valid email format)
- Course drop-down
- Submit button
- Template inheritance using base.html
- CSS loaded with url_for()
- CSRF protection via form.hidden_tag()

RUN IN VS CODE (WINDOWS)
------------------------
1. Extract this ZIP file.
2. Open the extracted StudentRegistration_Practical2 folder in VS Code.
3. Open Terminal > New Terminal. Choose Command Prompt if PowerShell blocks activation.
4. Create a virtual environment:
      python -m venv venv
5. Activate it in Command Prompt:
      venv\Scripts\activate
6. Install dependencies:
      pip install -r requirements.txt
7. Start the application:
      python app.py
8. Open in your browser:
      http://127.0.0.1:5000

To stop the server: press Ctrl+C.
To deactivate the virtual environment: type deactivate.

NOTE
----
This practical validates the submitted form and displays a success message.
It does not save student data in a database.
For a real project, replace the example SECRET_KEY with a secure secret value.

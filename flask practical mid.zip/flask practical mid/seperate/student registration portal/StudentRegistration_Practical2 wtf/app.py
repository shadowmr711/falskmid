from flask import Flask, render_template, redirect, url_for, flash
from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key"


class RegistrationForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(message="Please enter your name.")])
    email = StringField(
        "Email",
        validators=[
            DataRequired(message="Please enter your email."),
            Email(message="Please enter a valid email address.")
        ]
    )
    course = SelectField(
        "Course",
        choices=[
            ("", "Select Course"),
            ("MSc IT", "MSc IT"),
            ("BCA", "BCA"),
            ("BSc IT", "BSc IT"),
            ("MCA", "MCA")
        ],
        validators=[DataRequired(message="Please select a course.")]
    )
    submit = SubmitField("Register")


@app.route("/")
def home():
    return render_template("home.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        flash("Registration successful!", "success")
        return redirect(url_for("register"))

    return render_template("register.html", form=form)


if __name__ == "__main__":
    app.run(debug=True)
